/**
 * Ce package est le package gérant la fenetre d'affichage du formulaire ainsi que tous les controles (champs du formulaire)
 * C'est un package qui n'est pas utilisable par un programme externe
 */
package iut.algo.form.view;
