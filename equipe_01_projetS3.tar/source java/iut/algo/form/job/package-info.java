/**
 * Un package utile à la génération de formulaire, il contient les enumérations et le gestionnaire d'erreur utilisé pour la lecture du fichier xml
 * C'est un package qui n'est pas utilisable par un programme externe
 */
package iut.algo.form.job;
