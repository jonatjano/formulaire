/**
 * Il s'agit du package principal de l'utilitaire de génération de formulaire d'iut.algo
 * c'est ce package qui doit être importé par les étudiants
 */
package iut.algo.form;
